open scufed word 0.1.6.html file
