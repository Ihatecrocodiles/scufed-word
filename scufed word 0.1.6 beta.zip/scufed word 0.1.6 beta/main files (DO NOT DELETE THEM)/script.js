// this is the scripts file
console.log("hello console peaker");
	alert('welcome to scufed word 0.1.6')
document.getElementById("test").onclick = function() {
	console.log ("a")
	open("123.html")
}