//this is the second scripts file
document.getElementById("edit").onclick = function() {
alert('are you ready to save?')
print("pdf")
    console.log("saving...")
}
